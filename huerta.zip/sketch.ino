#include "DHT.h"

#define DHTPIN 15     // Pin conectado al SDA/DATA del DHT22
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200);
  dht.begin();
}

void loop() {
  delay(2000);

  float h = dht.readHumidity();
  float t = dht.readTemperature();

  if (isnan(h) || isnan(t)) {
    Serial.println("Error al leer el sensor DHT22");
    return;
  }

  Serial.print("Humedad: ");
  Serial.print(h);
  Serial.print("%  |  Temperatura: ");
  Serial.print(t);
  Serial.println("°C");
}