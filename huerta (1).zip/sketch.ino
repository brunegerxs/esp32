#include <WiFi.h>
#include <WebServer.h>
#include "DHT.h"

#define DHTPIN 15
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);
WebServer server(80);

const char* ssid = "Wokwi-GUEST";
const char* password = "";

void handleRoot() {
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();

  String html = "<html><head><meta http-equiv='refresh' content='2'>";
  html += "<style>body{font-family:Arial;text-align:center;margin-top:50px;}";
  html += ".card{display:inline-block;padding:20px;border-radius:10px;box-shadow:0 4px 8px rgba(0,0,0,0.2);}</style></head>";
  html += "<body><div class='card'><h1>ESP32 + DHT22</h1>";
  html += "<p><b>Temperatura:</b> " + String(temp) + " &deg;C</p>";
  html += "<p><b>Humedad:</b> " + String(hum) + " %</p>";
  html += "</div></body></html>";

  server.send(200, "text/html", html);
}

void setup() {
  Serial.begin(115200);
  dht.begin();

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nConectado a WiFi!");
  Serial.print("Direccion IP: ");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);
  server.begin();
}

void loop() {
  server.handleClient();
}